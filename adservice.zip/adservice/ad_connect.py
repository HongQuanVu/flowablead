from ldap3 import Server, \
    Connection, \
    AUTO_BIND_NO_TLS, \
    SUBTREE, \
    ALL_ATTRIBUTES


from ldap3.core.exceptions import  LDAPBindError

def authenticate_ad(username,password):
    # with Connection(Server('192.168.202.1', port=389, use_ssl=False),
    #                 auto_bind=AUTO_BIND_NO_TLS,
    #                 read_only=True,
    #                 check_names=True,
    #                 user='abc\\Administrator', password='Prudential01') as c:
    #     c.search(search_base='CN=Users,DC=abc,DC=local',
    #              search_filter='(&(samAccountName=' + u + '))',
    #              search_scope=SUBTREE,
    #              attributes=ALL_ATTRIBUTES,
    #              get_operational_attributes=True)

    #print(c.response_to_json())
    #print(c.result)

    try :
        conn =  Connection(Server('192.168.202.1', port=389, use_ssl=False),
                        auto_bind=AUTO_BIND_NO_TLS,
                        read_only=True,
                        check_names=True,
                        user=username, password=password)
    except LDAPBindError as e :
        print "Bind error :%s"%(e.message)
        return False
    return True