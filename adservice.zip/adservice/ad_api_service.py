from flask import Flask
import logging
from flask import request,jsonify
from ad_connect import authenticate_ad

app = Flask(__name__)

log = logging.getLogger('werkzeug')
#log.setLevel(logging.ERROR) #Disable Logging

#authenticate userid and password
#example :http://127.0.0.1:5000/api/v1.0/ad/authen?userid=quan&password=123
@app.route('/api/v1.0/ad/authen', methods=['GET'])
def ad_authenticate():
    userid =request.args.get("userid")
    password =request.args.get("password")
    isauthenticated = authenticate_ad(username=userid,password=password)
    if isauthenticated :
        result  =jsonify({"result":"OK","result_code":0,"error_mesasge":""})
        return   result
    else :
        result = jsonify({"result":"ERROR","result_code":1,"error_message":"unable to authenticate"})
        return   result

@app.route('/api/v1.0/ad/authen', methods=['POST'])
def ad_authenticate_by_post():

    request_body_json= request.json

    userid = request_body_json["userid"]
    password = request_body_json["password"]

    isauthenticated = authenticate_ad(username=userid,password=password)
    if isauthenticated:
        result = jsonify({"result": "OK", "result_code": 0, "error_mesasge": ""})
        return result
    else:
        result = jsonify({"result": "ERROR", "result_code": 1, "error_message": "unable to authenticate"})
        return result

@app.route('/', methods=['GET'])
def default_get():
   return "ok"


if __name__ == '__main__':
    #app.run(ssl_context='adhoc',host="localhost")
     app.run(host="localhost")